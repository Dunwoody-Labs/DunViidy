import boto3
import os
import urllib.parse
import logging

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Clients
s3 = boto3.client('s3')
ses = boto3.client('ses')

# Environment variables
EPHEMERAL_BUCKET = os.environ['BUCKET_NAME']
INPUT_BUCKET = os.environ['INPUT_BUCKET']
FROM_EMAIL = os.environ['FROM_EMAIL']

def lambda_handler(event, context):
    try:
        # Step 1: Get the uploaded .vtt file's key
        record = event['Records'][0]
        s3_key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        filename_base = os.path.splitext(os.path.basename(s3_key))[0]
        logger.info(f"Triggered by file: {s3_key}")

        # Step 2: Look for corresponding .txt file in input bucket
        txt_key = f"{filename_base}.txt"
        logger.info(f"Looking for email file: {txt_key} in {INPUT_BUCKET}")

        email_obj = s3.get_object(Bucket=INPUT_BUCKET, Key=txt_key)
        email_address = email_obj['Body'].read().decode('utf-8').strip()
        logger.info(f"Extracted email: {email_address}")

        # Step 3: Generate a presigned URL to the .vtt file
        presigned_url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': EPHEMERAL_BUCKET, 'Key': s3_key},
            ExpiresIn=86400  # 24 hours
        )
        logger.info(f"Generated presigned URL: {presigned_url}")

        # Step 4: Send the email using SES
        subject = "Your Transcription File is Ready"
        body_text = f"Hello,\n\nYour transcription file is ready:\n{presigned_url}\n\nThis link is valid for 24 hours."
        body_html = f"""
        <html>
        <head></head>
        <body>
          <p>Hello,</p>
          <p>Your transcription file is ready. You can download it using the link below:</p>
          <p><a href="{presigned_url}">Download Transcription</a></p>
          <p><em>This link is valid for 24 hours.</em></p>
        </body>
        </html>
        """

        response = ses.send_email(
            Source=FROM_EMAIL,
            Destination={'ToAddresses': [email_address]},
            Message={
                'Subject': {'Data': subject},
                'Body': {
                    'Text': {'Data': body_text},
                    'Html': {'Data': body_html}
                }
            }
        )

        logger.info(f"Email sent successfully: {response['MessageId']}")
        return {"statusCode": 200, "body": f"Email sent to {email_address}"}

    except Exception as e:
        logger.error(f"Error occurred: {str(e)}")
        return {"statusCode": 500, "body": f"Error sending email: {str(e)}"}